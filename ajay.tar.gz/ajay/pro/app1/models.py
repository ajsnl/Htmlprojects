from django.db import models

# Create your models here.
class employee(models.Model):
    Empid=models.IntegerField()
    Empname=models.CharField(max_length=25)
    Empdept=models.CharField(max_length=25)
    Empphone=models.TextField()
